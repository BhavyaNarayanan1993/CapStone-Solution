package com.order.bill.dto;

import jakarta.persistence.Embeddable;


public class CustomerAddressDTO {
	
	

	
	private String location;
	
	
	private String city;

	public String getLocation() {
		return location;
	}

	public String getCity() {
		return city;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public void setCity(String city) {
		this.city = city;
	}

	
	
	public CustomerAddressDTO() {
		super();
	}

	public CustomerAddressDTO(String location, String city) {
		super();
		this.location = location;
		this.city = city;
	}

	@Override
	public String toString() {
		return "CustomerAddress [location=" + location + ", city=" + city + "]";
	}
	
	
}
