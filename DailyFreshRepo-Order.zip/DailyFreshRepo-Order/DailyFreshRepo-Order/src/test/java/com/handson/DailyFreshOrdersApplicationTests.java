package com.handson;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DailyFreshOrdersApplicationTests {

	@Test
	void contextLoads() {
	}

}
